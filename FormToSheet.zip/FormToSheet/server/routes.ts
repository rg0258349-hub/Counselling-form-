import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCounsellingRegistrationSchema } from "@shared/schema";
import * as XLSX from "xlsx";

export async function registerRoutes(app: Express): Promise<Server> {
  // Counselling registration endpoint
  app.post("/api/counselling-registration", async (req, res) => {
    try {
      const validatedData = insertCounsellingRegistrationSchema.parse({
        ...req.body,
        counsellingDateTime: new Date(req.body.counsellingDateTime),
      });

      // Check for duplicate submissions using phone number
      if (storage.isDuplicateSubmission(validatedData.phoneNumber)) {
        return res.status(429).json({
          success: false,
          error: "Please wait before submitting another registration. If this was an error, try again in a few minutes."
        });
      }

      const registration = await storage.createCounsellingRegistration(validatedData);

      // Mark submission as complete to set cooldown timer
      storage.markSubmissionComplete(validatedData.phoneNumber);

      // Send to Google Sheets via Apps Script webhook
      const googleSheetsUrl = process.env.GOOGLE_SHEETS_WEBHOOK_URL;
      
      if (googleSheetsUrl) {
        try {
          const sheetData = {
            fullName: registration.fullName,
            address: registration.address,
            phoneNumber: registration.phoneNumber,
            studentClass: registration.studentClass,
            counsellingDateTime: registration.counsellingDateTime.toISOString(),
            submissionTime: registration.createdAt ? registration.createdAt.toISOString() : new Date().toISOString(),
          };
          
          const response = await fetch(googleSheetsUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(sheetData),
          });
          
          if (!response.ok) {
            console.error('Failed to send to Google Sheets:', response.statusText);
            // Continue with success even if Google Sheets fails
          }
        } catch (error) {
          console.error('Error sending to Google Sheets:', error);
          // Continue with success even if Google Sheets fails
        }
      }
      
      res.json({ success: true, data: registration });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ 
        success: false, 
        error: error instanceof Error ? error.message : "Registration failed" 
      });
    }
  });

  // Basic auth middleware for admin routes
  const requireAdminAuth = (req: any, res: any, next: any) => {
    const adminPassword = "Rohit@1807";
    const authHeader = req.headers.authorization;
    const expectedAuth = `Basic ${Buffer.from(`admin:${adminPassword}`).toString('base64')}`;
    
    if (!authHeader || authHeader !== expectedAuth) {
      res.set('WWW-Authenticate', 'Basic realm="Admin Access"');
      return res.status(401).json({ 
        success: false, 
        error: "Admin authentication required" 
      });
    }
    next();
  };

  // Get all registrations endpoint (admin only)
  app.get("/api/counselling-registrations", requireAdminAuth, async (req, res) => {
    try {
      const registrations = await storage.getCounsellingRegistrations();
      res.json({ success: true, data: registrations });
    } catch (error) {
      console.error("Fetch error:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to fetch registrations" 
      });
    }
  });

  // Download Excel file with all registrations (admin only)
  app.get("/api/counselling-registrations/download", requireAdminAuth, async (req, res) => {
    try {
      const registrations = await storage.getCounsellingRegistrations();
      
      // Prepare data for Excel
      const excelData = registrations.map((reg, index) => ({
        'S.No': index + 1,
        'Full Name': reg.fullName,
        'Address': reg.address,
        'Phone Number': reg.phoneNumber,
        'Student Class': reg.studentClass,
        'Counselling Date & Time': reg.counsellingDateTime.toLocaleString(),
        'Status': reg.status.charAt(0).toUpperCase() + reg.status.slice(1),
        'Registration Date': reg.createdAt ? reg.createdAt.toLocaleString() : 'N/A'
      }));

      // Create workbook and worksheet
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.json_to_sheet(excelData);
      
      // Auto-size columns
      const columnWidths = [
        { wch: 6 },   // S.No
        { wch: 20 },  // Full Name
        { wch: 30 },  // Address
        { wch: 15 },  // Phone Number
        { wch: 12 },  // Student Class
        { wch: 20 },  // Counselling Date & Time
        { wch: 12 },  // Status
        { wch: 18 }   // Registration Date
      ];
      worksheet['!cols'] = columnWidths;
      
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Counselling Registrations');
      
      // Generate Excel buffer
      const excelBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
      
      // Set response headers for file download
      const filename = `counselling_registrations_${new Date().toISOString().split('T')[0]}.xlsx`;
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Length', excelBuffer.length);
      
      res.send(excelBuffer);
    } catch (error) {
      console.error("Excel download error:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to generate Excel file" 
      });
    }
  });

  // Update registration status (admin only)
  app.patch("/api/counselling-registrations/:id/status", requireAdminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!['pending', 'finished', 'cancelled'].includes(status)) {
        return res.status(400).json({
          success: false,
          error: "Invalid status. Must be 'pending', 'finished', or 'cancelled'"
        });
      }
      
      const updatedRegistration = await storage.updateRegistrationStatus(id, status);
      
      if (!updatedRegistration) {
        return res.status(404).json({
          success: false,
          error: "Registration not found"
        });
      }
      
      res.json({ success: true, data: updatedRegistration });
    } catch (error) {
      console.error("Status update error:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to update status" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
