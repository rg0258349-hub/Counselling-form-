# Counselling Registration System

## Overview

A web application for educational institutions to manage student counselling session registrations. The system provides a user-friendly form for parents/students to book counselling appointments and includes an admin dashboard for viewing submissions. Built with React frontend, Express backend, and integrates with Google Sheets for data backup.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with Tailwind CSS for styling
- **Form Management**: React Hook Form with Zod validation for type-safe form handling
- **State Management**: TanStack Query for server state management and API calls
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Data Storage**: In-memory storage with planned PostgreSQL integration via Drizzle ORM
- **Validation**: Zod schemas shared between frontend and backend
- **Session Management**: Built-in duplicate submission prevention with cooldown timers

### Data Storage Solutions
- **Primary Storage**: In-memory storage (MemStorage class) for development/testing
- **Database Ready**: Drizzle ORM configured for PostgreSQL with migration support
- **Backup Storage**: Google Sheets integration via Apps Script webhook
- **Schema Management**: Shared TypeScript types and Zod validation schemas

### Authentication and Authorization
- **Admin Access**: Simple password-based authentication for admin dashboard
- **Session Storage**: Browser sessionStorage for maintaining admin login state
- **Rate Limiting**: Built-in duplicate submission prevention using phone number tracking

### Key Features
- **Form Validation**: Comprehensive client and server-side validation for all form fields
- **Duplicate Prevention**: 5-minute cooldown period between submissions from same phone number
- **Responsive Design**: Mobile-first design with Tailwind CSS
- **Error Handling**: User-friendly error messages and loading states
- **Success Feedback**: Modal confirmation for successful submissions

## External Dependencies

### Third-Party Services
- **Google Sheets API**: Data backup and spreadsheet integration via Apps Script webhook
- **Google Fonts**: Typography (Inter, DM Sans, Architects Daughter, Fira Code, Geist Mono)

### Database Services
- **Neon Database**: PostgreSQL hosting service (@neondatabase/serverless)
- **Drizzle ORM**: Type-safe database operations and migrations

### UI and Styling
- **Radix UI**: Comprehensive component library for accessible UI elements
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Fast build tool and development server
- **ESBuild**: JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer
- **TanStack Query**: Server state management and caching

### Form and Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: TypeScript-first schema validation
- **@hookform/resolvers**: Validation resolver for React Hook Form

### Utilities
- **date-fns**: Modern JavaScript date utility library
- **clsx**: Conditional className utility
- **class-variance-authority**: Component variant utility