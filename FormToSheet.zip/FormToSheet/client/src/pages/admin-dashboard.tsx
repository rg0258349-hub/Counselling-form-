import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { type CounsellingRegistration } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CalendarDays, Phone, MapPin, GraduationCap, Clock, Lock, Download, Check, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [authAttempted, setAuthAttempted] = useState(false);
  const { toast } = useToast();

  // Check if credentials are stored on mount
  useEffect(() => {
    const stored = sessionStorage.getItem('admin-auth');
    if (stored) {
      setIsAuthenticated(true);
    }
  }, []);

  const { data: registrationsData, isLoading, error } = useQuery({
    queryKey: ["/api/counselling-registrations"],
    queryFn: async () => {
      const storedAuth = sessionStorage.getItem('admin-auth');
      const response = await fetch("/api/counselling-registrations", {
        headers: storedAuth ? {
          'Authorization': storedAuth
        } : {}
      });
      
      if (response.status === 401) {
        sessionStorage.removeItem('admin-auth');
        setIsAuthenticated(false);
        throw new Error("Authentication required");
      }
      
      if (!response.ok) {
        throw new Error("Failed to fetch registrations");
      }
      const data = await response.json();
      return data.data as CounsellingRegistration[];
    },
    enabled: isAuthenticated,
  });

  const handleLogin = async () => {
    setAuthError("");
    setAuthAttempted(true);
    
    const auth = `Basic ${btoa(`admin:${password}`)}`;
    
    try {
      const response = await fetch("/api/counselling-registrations", {
        headers: {
          'Authorization': auth
        }
      });
      
      if (response.ok) {
        sessionStorage.setItem('admin-auth', auth);
        setIsAuthenticated(true);
        setPassword(""); // Clear password from state
      } else if (response.status === 401) {
        setAuthError("Invalid password");
      } else {
        setAuthError("Authentication failed");
      }
    } catch (error) {
      setAuthError("Connection error");
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('admin-auth');
    setIsAuthenticated(false);
    setAuthAttempted(false);
    setAuthError("");
  };

  // Status update mutation
  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: "pending" | "finished" | "cancelled" }) => {
      const storedAuth = sessionStorage.getItem('admin-auth');
      const response = await fetch(`/api/counselling-registrations/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(storedAuth ? { 'Authorization': storedAuth } : {})
        },
        body: JSON.stringify({ status })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to update status");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/counselling-registrations"] });
      toast({
        title: "Status Updated",
        description: "Registration status has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Excel download function
  const handleExcelDownload = async () => {
    try {
      const storedAuth = sessionStorage.getItem('admin-auth');
      const response = await fetch('/api/counselling-registrations/download', {
        headers: storedAuth ? { 'Authorization': storedAuth } : {}
      });
      
      if (!response.ok) {
        throw new Error('Failed to download Excel file');
      }
      
      // Create blob and download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `counselling_registrations_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download Successful",
        description: "Excel file has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download Excel file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleStatusUpdate = (id: string, status: "finished" | "cancelled") => {
    statusMutation.mutate({ id, status });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'finished':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen p-6 bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Lock className="h-5 w-5" />
              Admin Login
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                data-testid="input-admin-password"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>
            
            {authError && (
              <p className="text-sm text-destructive" data-testid="text-auth-error">
                {authError}
              </p>
            )}
            
            <Button 
              onClick={handleLogin}
              className="w-full"
              disabled={!password}
              data-testid="button-login"
            >
              Login
            </Button>
            
            <div className="text-center">
              <a 
                href="/" 
                className="text-sm text-primary hover:text-primary/80 underline"
                data-testid="link-back-to-form"
              >
                Back to Form
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const registrations = registrationsData || [];
  const pendingRegistrations = registrations.filter(reg => reg.status === 'pending');
  const finishedRegistrations = registrations.filter(reg => reg.status === 'finished');
  const cancelledRegistrations = registrations.filter(reg => reg.status === 'cancelled');

  if (isLoading) {
    return (
      <div className="min-h-screen p-6 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading registrations...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen p-6 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <p className="text-destructive mb-2">Failed to load registrations</p>
              <p className="text-muted-foreground text-sm">{error.message}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Admin Dashboard</h1>
              <p className="text-muted-foreground">Manage counselling registrations</p>
            </div>
            <div className="flex gap-4 items-center">
              <Button
                onClick={handleExcelDownload}
                className="bg-green-600 hover:bg-green-700 text-white"
                data-testid="button-excel-download"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Excel
              </Button>
              <a 
                href="/" 
                className="text-sm text-primary hover:text-primary/80 underline"
                data-testid="link-form"
              >
                Back to Form
              </a>
              <button
                onClick={handleLogout}
                className="text-sm text-muted-foreground hover:text-foreground underline"
                data-testid="button-logout"
              >
                Logout
              </button>
            </div>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium">Total Registrations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">{registrations.length}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium">Recent Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {registrations.filter(reg => {
                    const yesterday = new Date();
                    yesterday.setDate(yesterday.getDate() - 1);
                    return new Date(reg.createdAt) > yesterday;
                  }).length}
                </div>
                <p className="text-sm text-muted-foreground">Last 24 hours</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium">Upcoming Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {pendingRegistrations.filter(reg => {
                    return new Date(reg.counsellingDateTime) > new Date();
                  }).length}
                </div>
                <p className="text-sm text-muted-foreground">Pending appointments</p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          {/* Pending Registrations */}
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-4">Pending Registrations</h2>
            
            {pendingRegistrations.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <CalendarDays className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No pending registrations</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {pendingRegistrations
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((registration) => (
                    <Card key={registration.id} className="hover:shadow-md transition-shadow" data-testid={`card-registration-${registration.id}`}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg font-medium" data-testid={`text-name-${registration.id}`}>
                            {registration.fullName}
                          </CardTitle>
                          <div className="flex gap-2">
                            <Badge className={getStatusColor(registration.status)}>
                              {registration.status.charAt(0).toUpperCase() + registration.status.slice(1)}
                            </Badge>
                            <Badge variant={
                              new Date(registration.counsellingDateTime) > new Date() ? "default" : "secondary"
                            }>
                              {new Date(registration.counsellingDateTime) > new Date() ? "Upcoming" : "Past"}
                            </Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-start gap-3">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="text-sm text-foreground" data-testid={`text-address-${registration.id}`}>
                              {registration.address}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground" data-testid={`text-phone-${registration.id}`}>
                            {registration.phoneNumber}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <GraduationCap className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground" data-testid={`text-class-${registration.id}`}>
                            {registration.studentClass}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <CalendarDays className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground" data-testid={`text-datetime-${registration.id}`}>
                            {new Date(registration.counsellingDateTime).toLocaleString()}
                          </p>
                        </div>
                        
                        <div className="flex items-center gap-3 pt-2 border-t">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <p className="text-xs text-muted-foreground" data-testid={`text-submitted-${registration.id}`}>
                            Submitted: {new Date(registration.createdAt).toLocaleString()}
                          </p>
                        </div>
                        
                        <div className="flex gap-2 pt-3 border-t">
                          <Button
                            onClick={() => handleStatusUpdate(registration.id, 'finished')}
                            className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                            disabled={statusMutation.isPending}
                            data-testid={`button-finished-${registration.id}`}
                          >
                            <Check className="h-4 w-4 mr-2" />
                            Finished
                          </Button>
                          <Button
                            onClick={() => handleStatusUpdate(registration.id, 'cancelled')}
                            variant="outline"
                            className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                            disabled={statusMutation.isPending}
                            data-testid={`button-cancel-${registration.id}`}
                          >
                            <X className="h-4 w-4 mr-2" />
                            Cancel
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </div>

          {/* Finished Registrations */}
          {finishedRegistrations.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-foreground mb-4">Finished Registrations</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {finishedRegistrations
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((registration) => (
                    <Card key={registration.id} className="opacity-75" data-testid={`card-registration-${registration.id}`}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg font-medium" data-testid={`text-name-${registration.id}`}>
                            {registration.fullName}
                          </CardTitle>
                          <Badge className={getStatusColor(registration.status)}>
                            {registration.status.charAt(0).toUpperCase() + registration.status.slice(1)}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex items-center gap-3">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground">{registration.phoneNumber}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <CalendarDays className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground">
                            {new Date(registration.counsellingDateTime).toLocaleString()}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          )}

          {/* Cancelled Registrations */}
          {cancelledRegistrations.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold text-foreground mb-4">Cancelled Registrations</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {cancelledRegistrations
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((registration) => (
                    <Card key={registration.id} className="opacity-75" data-testid={`card-registration-${registration.id}`}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg font-medium" data-testid={`text-name-${registration.id}`}>
                            {registration.fullName}
                          </CardTitle>
                          <Badge className={getStatusColor(registration.status)}>
                            {registration.status.charAt(0).toUpperCase() + registration.status.slice(1)}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex items-center gap-3">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground">{registration.phoneNumber}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <CalendarDays className="h-4 w-4 text-muted-foreground" />
                          <p className="text-sm text-foreground">
                            {new Date(registration.counsellingDateTime).toLocaleString()}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}