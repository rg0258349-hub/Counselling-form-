import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const counsellingRegistrations = pgTable("counselling_registrations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fullName: text("full_name").notNull(),
  address: text("address").notNull(),
  phoneNumber: text("phone_number").notNull(),
  studentClass: text("student_class").notNull(),
  counsellingDateTime: timestamp("counselling_date_time").notNull(),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCounsellingRegistrationSchema = createInsertSchema(counsellingRegistrations)
  .omit({
    id: true,
    status: true,
    createdAt: true,
  })
  .extend({
    fullName: z.string()
      .min(2, "Full name must be at least 2 characters")
      .max(100, "Full name cannot exceed 100 characters")
      .regex(/^[a-zA-Z\s'-]+$/, "Full name should only contain letters, spaces, hyphens and apostrophes"),
    address: z.string()
      .min(10, "Please enter a complete address (at least 10 characters)")
      .max(500, "Address cannot exceed 500 characters")
      .refine(val => val.trim().split(/\s+/).length >= 3, "Please provide a detailed address with street, city, etc."),
    phoneNumber: z.string()
      .min(10, "Phone number must be at least 10 digits")
      .max(15, "Phone number cannot exceed 15 digits")
      .regex(/^[\+]?[1-9][\d\s\-\(\)]{8,17}$/, "Please enter a valid phone number (e.g., +1234567890, (123) 456-7890, or 1234567890)")
      .refine(val => val.replace(/\D/g, '').length >= 10, "Phone number must contain at least 10 digits"),
    studentClass: z.string()
      .min(1, "Please select your child's class from the dropdown"),
    counsellingDateTime: z.date()
      .refine(
        (date) => date > new Date(),
        "Please select a future date and time for your counselling session"
      )
      .refine(
        (date) => {
          const now = new Date();
          const tomorrow = new Date(now);
          tomorrow.setDate(now.getDate() + 1);
          return date >= tomorrow;
        },
        "Counselling sessions must be scheduled at least 24 hours in advance"
      )
      .refine(
        (date) => {
          const maxDate = new Date();
          maxDate.setMonth(maxDate.getMonth() + 6);
          return date <= maxDate;
        },
        "Please schedule your session within the next 6 months"
      ),
  });

export type InsertCounsellingRegistration = z.infer<typeof insertCounsellingRegistrationSchema>;
export type CounsellingRegistration = typeof counsellingRegistrations.$inferSelect;

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
