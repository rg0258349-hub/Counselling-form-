import { type User, type InsertUser, type CounsellingRegistration, type InsertCounsellingRegistration } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createCounsellingRegistration(registration: InsertCounsellingRegistration): Promise<CounsellingRegistration>;
  getCounsellingRegistrations(): Promise<CounsellingRegistration[]>;
  updateRegistrationStatus(id: string, status: "pending" | "finished" | "cancelled"): Promise<CounsellingRegistration | undefined>;
  isDuplicateSubmission(phoneNumber: string, email?: string): boolean;
  markSubmissionComplete(phoneNumber: string): void;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private registrations: Map<string, CounsellingRegistration>;
  private recentSubmissions: Map<string, number>;

  constructor() {
    this.users = new Map();
    this.registrations = new Map();
    this.recentSubmissions = new Map();
    
    // Clean up old submissions every 5 minutes
    setInterval(() => {
      const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
      const keysToDelete: string[] = [];
      
      this.recentSubmissions.forEach((timestamp, key) => {
        if (timestamp < fiveMinutesAgo) {
          keysToDelete.push(key);
        }
      });
      
      keysToDelete.forEach(key => this.recentSubmissions.delete(key));
    }, 5 * 60 * 1000);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createCounsellingRegistration(insertRegistration: InsertCounsellingRegistration): Promise<CounsellingRegistration> {
    const id = randomUUID();
    const registration: CounsellingRegistration = {
      ...insertRegistration,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.registrations.set(id, registration);
    return registration;
  }

  async getCounsellingRegistrations(): Promise<CounsellingRegistration[]> {
    return Array.from(this.registrations.values());
  }

  async updateRegistrationStatus(id: string, status: "pending" | "finished" | "cancelled"): Promise<CounsellingRegistration | undefined> {
    const registration = this.registrations.get(id);
    if (!registration) {
      return undefined;
    }
    
    const updatedRegistration = { ...registration, status };
    this.registrations.set(id, updatedRegistration);
    return updatedRegistration;
  }

  isDuplicateSubmission(phoneNumber: string, email?: string): boolean {
    // Normalize phone number: remove all non-digits and keep last 10 digits for consistent comparison
    const normalizedPhone = phoneNumber.replace(/\D/g, '').slice(-10);
    const key = normalizedPhone; // Use normalized phone number as the primary key for duplicate detection
    const now = Date.now();
    const lastSubmission = this.recentSubmissions.get(key);
    
    // If no previous submission or more than 5 minutes ago, allow it
    if (!lastSubmission || (now - lastSubmission) > 5 * 60 * 1000) {
      return false; // Allow submission, but don't set timestamp yet
    }
    
    // Duplicate submission detected
    return true;
  }

  markSubmissionComplete(phoneNumber: string): void {
    // Mark submission as complete - set the cooldown timestamp
    const normalizedPhone = phoneNumber.replace(/\D/g, '').slice(-10);
    this.recentSubmissions.set(normalizedPhone, Date.now());
  }
}

export const storage = new MemStorage();
