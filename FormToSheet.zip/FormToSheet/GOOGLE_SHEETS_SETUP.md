# Google Sheets Integration Setup

Follow these steps to connect your counselling form to Google Sheets:

## Step 1: Create a Google Sheet

1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "Counselling Registrations" or any name you prefer
4. Add these column headers in row 1:
   - A1: `Full Name`
   - B1: `Address` 
   - C1: `Phone Number`
   - D1: `Class`
   - E1: `Counselling Date & Time`
   - F1: `Submission Time`

## Step 2: Create Google Apps Script

1. In your Google Sheet, go to **Extensions** → **Apps Script**
2. Delete any existing code and paste this script:

```javascript
function doPost(e) {
  try {
    // Get the active spreadsheet
    const sheet = SpreadsheetApp.getActiveSheet();
    
    // Parse the JSON data
    const data = JSON.parse(e.postData.contents);
    
    // Format the dates for better readability
    const counsellingDate = new Date(data.counsellingDateTime);
    const submissionDate = new Date(data.submissionTime);
    
    // Add the data as a new row
    sheet.appendRow([
      data.fullName,
      data.address,
      data.phoneNumber,
      data.studentClass,
      counsellingDate.toLocaleString(),
      submissionDate.toLocaleString()
    ]);
    
    // Return success response
    return ContentService
      .createTextOutput(JSON.stringify({result: 'success'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    // Return error response
    return ContentService
      .createTextOutput(JSON.stringify({result: 'error', message: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

3. Save the script (Ctrl+S or Cmd+S)
4. Click **Deploy** → **New deployment**
5. Under "Type", select **Web app**
6. Set these options:
   - Description: "Counselling Form Webhook"
   - Execute as: **Me**
   - Who has access: **Anyone**
7. Click **Deploy**
8. **Copy the Web app URL** - you'll need this!

## Step 3: Configure Your Replit App

1. In your Replit project, go to the **Secrets** tab (🔒 icon in sidebar)
2. Add these secrets:
   - Key: `GOOGLE_SHEETS_WEBHOOK_URL`
   - Value: Paste the Web app URL you copied from step 2
   
   - Key: `ADMIN_PASSWORD` (optional, for admin dashboard security)
   - Value: Choose a strong password for admin access
3. Restart your application

**Note**: If you set an `ADMIN_PASSWORD`, you'll need to enter "admin" as the username and your chosen password when accessing the admin dashboard at `/admin`.

## Step 4: Test the Integration

1. Fill out and submit the counselling form
2. Check your Google Sheet - the data should appear automatically!
3. You can download the sheet as Excel (.xlsx) anytime by going to **File** → **Download** → **Microsoft Excel (.xlsx)**

## Troubleshooting

- **Data not appearing?** Check that the webhook URL is correct in your Secrets
- **Permission errors?** Make sure the Apps Script deployment has "Who has access: Anyone"
- **Still having issues?** Check the Apps Script execution logs in the Google Apps Script editor

## Security Note

The webhook URL is unique to your Google Apps Script and can only add data to your specific sheet. Keep it secure and don't share it publicly.