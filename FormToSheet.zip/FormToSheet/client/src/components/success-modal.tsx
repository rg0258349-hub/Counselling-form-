import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SuccessModal({ isOpen, onClose }: SuccessModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px] p-0 overflow-hidden" data-testid="success-modal">
        <div className="success-modal">
          <div className="success-icon">
            <Check className="success-checkmark" data-testid="success-icon" />
          </div>
          <h2 className="success-title">Success!</h2>
          <p className="success-message">Your details have been submitted successfully!</p>
          <Button 
            onClick={onClose}
            className="success-button"
            data-testid="button-close-success"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
