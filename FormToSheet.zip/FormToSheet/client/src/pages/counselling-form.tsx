import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertCounsellingRegistrationSchema, type InsertCounsellingRegistration } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { SuccessModal } from "@/components/success-modal";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const gradeOptions = [
  "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6",
  "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
];

export default function CounsellingForm() {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<InsertCounsellingRegistration>({
    resolver: zodResolver(insertCounsellingRegistrationSchema),
    defaultValues: {
      fullName: "",
      address: "",
      phoneNumber: "",
      studentClass: "",
      counsellingDateTime: new Date(),
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (data: InsertCounsellingRegistration) => {
      console.log("Submitting registration data:", data);
      
      const response = await fetch("/api/counselling-registration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      console.log("Response status:", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Submission error response:", errorData);
        throw new Error(errorData.error || "Submission failed");
      }
      
      const result = await response.json();
      console.log("Submission successful:", result);
      return result;
    },
    onSuccess: () => {
      setIsSubmitted(true);
      setShowSuccessModal(true);
      form.reset();
    },
    onError: (error: Error) => {
      // Handle server errors, especially duplicate submission errors
      console.error("Submission error:", error.message);
      
      toast({
        title: "Submission Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertCounsellingRegistration) => {
    // Prevent duplicate submissions
    if (submitMutation.isPending || isSubmitted) {
      return;
    }
    submitMutation.mutate(data);
  };

  // Set minimum date to tomorrow in local time
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  // Format as YYYY-MM-DDTHH:mm in local time
  const year = tomorrow.getFullYear();
  const month = String(tomorrow.getMonth() + 1).padStart(2, '0');
  const day = String(tomorrow.getDate()).padStart(2, '0');
  const hours = String(tomorrow.getHours()).padStart(2, '0');
  const minutes = String(tomorrow.getMinutes()).padStart(2, '0');
  const minDateTime = `${year}-${month}-${day}T${hours}:${minutes}`;

  return (
    <div className="form-container">
      <div className="form-card">
        <div className="form-header">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="form-title">Counselling Registration</h1>
              <p className="form-subtitle">Please fill in your details to schedule a counselling session</p>
            </div>
            <a 
              href="/admin" 
              className="text-sm text-primary hover:text-primary/80 underline"
              data-testid="link-admin"
            >
              Admin View
            </a>
          </div>
        </div>
        

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="counselling-form">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem className="form-group">
                  <FormLabel className="form-label">
                    Full Name <span className="required">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field}
                      placeholder="Enter your full name"
                      className="form-input"
                      data-testid="input-full-name"
                    />
                  </FormControl>
                  <FormMessage className="error-message" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem className="form-group">
                  <FormLabel className="form-label">
                    Address <span className="required">*</span>
                  </FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field}
                      placeholder="Enter your complete address"
                      className="form-textarea"
                      rows={3}
                      data-testid="input-address"
                    />
                  </FormControl>
                  <FormMessage className="error-message" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phoneNumber"
              render={({ field }) => (
                <FormItem className="form-group">
                  <FormLabel className="form-label">
                    Phone Number <span className="required">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field}
                      type="tel"
                      placeholder="Enter your phone number"
                      className="form-input"
                      data-testid="input-phone-number"
                    />
                  </FormControl>
                  <FormMessage className="error-message" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="studentClass"
              render={({ field }) => (
                <FormItem className="form-group">
                  <FormLabel className="form-label">
                    Class <span className="required">*</span>
                  </FormLabel>
                  <Select onValueChange={field.onChange} value={field.value} data-testid="select-class">
                    <FormControl>
                      <SelectTrigger className="form-select">
                        <SelectValue placeholder="Select class" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {gradeOptions.map((grade) => (
                        <SelectItem key={grade} value={grade}>
                          {grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage className="error-message" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="counsellingDateTime"
              render={({ field }) => (
                <FormItem className="form-group">
                  <FormLabel className="form-label">
                    Preferred Counselling Date & Time <span className="required">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field}
                      type="datetime-local"
                      min={minDateTime}
                      className="form-input"
                      value={field.value ? (() => {
                        const date = new Date(field.value);
                        const year = date.getFullYear();
                        const month = String(date.getMonth() + 1).padStart(2, '0');
                        const day = String(date.getDate()).padStart(2, '0');
                        const hours = String(date.getHours()).padStart(2, '0');
                        const minutes = String(date.getMinutes()).padStart(2, '0');
                        return `${year}-${month}-${day}T${hours}:${minutes}`;
                      })() : ""}
                      onChange={(e) => {
                        if (e.target.value) {
                          field.onChange(new Date(e.target.value));
                        }
                      }}
                      data-testid="input-counselling-datetime"
                    />
                  </FormControl>
                  <FormMessage className="error-message" />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="submit-button w-full"
              disabled={submitMutation.isPending || isSubmitted}
              data-testid="button-submit"
            >
              {submitMutation.isPending ? (
                <>
                  <Loader2 className="loading-spinner" />
                  Submitting...
                </>
              ) : isSubmitted ? (
                "Successfully Submitted!"
              ) : (
                "Submit Registration"
              )}
            </Button>
          </form>
        </Form>
      </div>

      <SuccessModal 
        isOpen={showSuccessModal} 
        onClose={() => {
          setShowSuccessModal(false);
          setIsSubmitted(false); // Reset submitted state to allow future submissions
        }} 
      />
    </div>
  );
}
